# docker-django-redis-celery
Initial configuration of Docker Django Redis Celery

## Getting Started
This project works on Python 3+ and Django 2+.
Simply, run the following command:
```
docker-compose up --build
```

Follow me on IG for more: https://www.instagram.com/coderasha
